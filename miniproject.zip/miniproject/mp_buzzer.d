mp_buzzer.o: mp_buzzer.c
mp_buzzer.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
mp_buzzer.o: mp_defines.h
mp_buzzer.o: mp_declaration.h
