mp_defines.o: mp_defines.c
