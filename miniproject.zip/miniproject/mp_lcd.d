mp_lcd.o: mp_lcd.c
mp_lcd.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
mp_lcd.o: mp_declaration.h
mp_lcd.o: mp_defines.h
