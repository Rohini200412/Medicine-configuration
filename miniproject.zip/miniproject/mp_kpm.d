mp_kpm.o: mp_kpm.c
mp_kpm.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
mp_kpm.o: mp_defines.h
mp_kpm.o: mp_declaration.h
