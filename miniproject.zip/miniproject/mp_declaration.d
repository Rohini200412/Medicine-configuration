mp_declaration.o: mp_declaration.c
