mp_rtc.o: mp_rtc.c
mp_rtc.o: mp_defines.h
mp_rtc.o: mp_declaration.h
mp_rtc.o: C:\KeilARM\ARM\INC\Philips\lpc214x.h
