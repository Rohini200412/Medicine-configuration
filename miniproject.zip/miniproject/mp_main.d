mp_main.o: mp_main.c
mp_main.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
mp_main.o: mp_defines.h
mp_main.o: mp_declaration.h
