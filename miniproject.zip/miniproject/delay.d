delay.o: delay.c
delay.o: mp_declaration.h
